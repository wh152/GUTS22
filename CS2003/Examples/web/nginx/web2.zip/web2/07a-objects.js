/*
 * More objects -- from class definitions.
 * Saleem Bhatti, Sep 2018.
 */

"use strict";

function valueToString(v) { // Not exhaustively tested: only for demo!
  if (v === null) { return "(null)"; } // null is not a type

  let s = "?";

  switch (typeof v) {

    case "number":
    case "boolean":
    case "symbol":
    s = v.toString();
    break;

    case "string":
    s = "\"" + v + "\"";
    break;

    case "function":
    s = "(function)";
    break;

    case "undefined":
    v = "(undefined)";
    break;

    case "object":
    s = objectDump(v);
    break;

    default: // should not get here!
    s = "?";
    break;
  }

  return (s);
}

function objectDump(o) {
  let s = "{";
  for (let p in o) {
    if (s != "{") { s = s + ", "; }
    let v = valueToString(o[p]);
    s = s + p + " : " + v;
  }
  s = s + "}";
  return s;
}

// simple Person
class Person {
  constructor(name, info) {
    this.name = name;
    this.info = info;
  }

  who() { return (this.name + " (" + this.info + ")"); }
}

// simple Gaul
class Gaul extends Person {
  constructor(name, info, potion) {
    super(name, info);
    this.potion = potion;
  }

  todo() { return ("Bash the Romans!"); }
}

// simple Roman
class Roman extends Person {
  constructor(name, info) {
    super(name, info);
  }

  todo() { return ("Runaway from the Gauls!"); }
}

let folks = new Array();

folks[0] = new Gaul("Asterix", "short", true);
folks[1] = new Gaul("Obelix", "large", false);
folks[2] = new Gaul("Hydrophobia",  "a tradeswoman", true);
folks[3] = new Gaul("Vitalstatistix", "the boss!", true);
folks[4] = new Gaul("Impedimenta", "the best cook", true);
folks[5] = new Roman("Gluteus Maximus", "a legionary");
folks[6] = new Roman("Julius Caesar", "also the boss");
folks[7] = new Roman("Brutus", "treacherous");
folks[8] = new Roman("Nefarius Purpus", "a frantic centurion");

for (let f of folks) {
  let s = "--> " + f.who();
  if (f instanceof Gaul) {
    s = s + " is" + (f.potion ? " " : " *not* ") + "allowed to drink potion";
  }

  console.log(s);
  console.log(objectDump(f) + "\n");
}
