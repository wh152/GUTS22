/*
 * Some more examples of functions.
 * Saleem Bhatti, Sep 2018.
 */
"use strict";

function timesTables(v) {
  if (typeof v != "number") { return (null); }

  let tables = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

  return (tables.map(x => x * v));
}

let t3 = timesTables(3);
console.log(t3);

let t5 = timesTables(5);
console.log(t5);


function timesTablesFunction(v) {
  if (typeof v != "number") { return (null); }

  let tables = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

  return (function(t) {
            return (tables.map(x => x * v));
          }
        );
}

let t3f = timesTablesFunction(3);
console.log(t3f);
console.log(t3f());

let t5f = timesTablesFunction(5);
console.log(t5f);
console.log(t5f());
