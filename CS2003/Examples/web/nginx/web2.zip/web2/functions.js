/*
 * Some examples of functions.
 * Saleem Bhatti, Sep 2018.
 */
"use strict";

let i1 = 42; // integer -- actually, floating point number
let i2 = 3;

let s1 = "forty_two"; // string
let s2 = "three";

let f1 = 42.424242; /* 64-bit floating point */
let f2 = 3.3333;

let array_1 = [42, 3, 42.424242, 3.3333];
let array_2 = [i1, i2, f1, f2];
let array_3 = [s1, 42, s2, 3];
let array_4a = {s1 : i1, s2 : i2, "42?" : f1, "3?" : f2}; // JSON object
let array_4b = {[s1] : i1, [s2] : i2, "42?" : f1, "3?" : f2}; // JSON object

function value(v) {
  if (v == i1) { return ("you have the answer"); }
  else if (v == i2) { return ("that is a crowd"); }
  else { return ("this value is nothing special"); }
}

console.log(value(i1));
console.log(value(i2));
console.log(value("42") + " (look at the code!)");
console.log(value("3")+ " (look at the code!)");

console.log(value(s1));
console.log(value(s2));
console.log(value(f1));
console.log(value(f2));
