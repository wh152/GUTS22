/*
 * Some examples of displaying values.
 * Saleem Bhatti, Sep 2018.
 */
"use strict";

let i1 = 42; // integer -- actually, floating point number
let i2 = 3;

let s1 = "forty_two"; // string
let s2 = "three";

let f1 = 42.424242; /* 64-bit floating point */
let f2 = 3.3333;

let array_1 = [42, 3, 42.424242, 3.3333];
let array_2 = [i1, i2, f1, f2];
let array_3 = [s1, 42, s2, 3];
let array_4a = {s1 : i1, s2 : i2, "42?" : f1, "3?" : f2}; // JSON object
let array_4b = {[s1] : i1, [s2] : i2, "42?" : f1, "3?" : f2}; // JSON object

console.log(i1);

console.log(i1,i2);

console.log(s1, s2);

console.log(f1, f2);

console.log(array_1);

console.log(array_2);

console.log(array_3);

console.log(array_4a);

console.log(array_4b);
