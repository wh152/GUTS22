/*
 * Some examples of conditional statements.
 * Saleem Bhatti, Sep 2018.
 */
"use strict";

let i1 = 42; // integer -- actually, floating point number
let i2 = 3;

let s1 = "forty_two"; // string
let s2 = "three";

let f1 = 42.424242; /* 64-bit floating point */
let f2 = 3.3333;

let array_1 = [42, 3, 42.424242, 3.3333];
let array_2 = [i1, i2, f1, f2];
let array_3 = [s1, 42, s2, 3];
let array_4a = {s1 : i1, s2 : i2, "42?" : f1, "3?" : f2}; // JSON object
let array_4b = {[s1] : i1, [s2] : i2, "42?" : f1, "3?" : f2}; // JSON object

console.log("\narray_4b - if ... esle if ...");
for(let k in array_4b) {
 if (k == s1) {
   console.log("The answer.");
 }
 else if (k == s2) {
   console.log("A crowd.");
 }
 else if (k == "42?") {
   console.log("More than enough.");
 }
 else if (k == "3?") {
   console.log("More than a crowd.");
 }
 else {
   console.log("What?");
 }
}

console.log("\narray_4b - switch");
for(let k in array_4b) {

  switch (k) {

    case s1:
    console.log("The answer.");
    break;

    case s2:
    console.log("A crowd.");
    break;

    case "42?":
    console.log("More than enough.");
    break;

    case "3?":
    console.log("More than a crowd.");
    break;

    default:
    console.log("What?");
    break;
  }
}

console.log("\narray_4b[\"forty_two\"] -> " + array_4b["forty_two"]);
console.log("\narray_4b.three -> " + array_4b.three);
