/*
 * Dump info in an object.
 * Saleem Bhatti, Sep 2018.
 */
"use strict";

function valueToString(v) { // Not exhaustively tested: only for demo!
  if (v === null) { return "(null)"; } // null is not a type

  let s = "?";

  switch (typeof v) {

    case "number":
    case "boolean":
    case "symbol":
    s = v.toString();
    break;

    case "string":
    s = "\"" + v + "\"";
    break;

    case "function":
    s = "(function)";
    break;

    case "undefined":
    v = "(undefined)";
    break;

    case "object":
    s = objectDump(v);
    break;

    default: // should not get here!
    s = "?";
    break;
  }

  return (s);
}

function objectDump(o) {
  let s = "{";
  for (let p in o) {
    if (s != "{") { s = s + ", "; }
    let v = valueToString(o[p]);
    s = s + p + " : " + v;
  }
  s = s + "}";
  return s;
}
