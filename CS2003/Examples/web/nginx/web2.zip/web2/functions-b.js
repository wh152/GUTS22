/*
 * Yet more examples of functions.
 * Saleem Bhatti, Sep 2018.
 */
"use strict";

console.log("--> Using Function() could impact performance and security!");

let muxer = new Function("x", "return function(y) { return x * y; };");
let x3 = muxer(3);
let x42 = muxer(42);

for (let n = 1; n <= 5; ++n) {
  console.log("n=" + n + " : x3=" + x3(n) + " : x42=" + x42(n));
}
