// Saleem Bhatti, Sep 2018
"use strict";

console.log("Hello World!");
alert("Hello World! - be alert: the world needs lerts");
