// Saleem Bhatti, Sep 2018
"use strict";

console.log("Hello World!");
