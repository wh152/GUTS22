/*
 * Some examples of objects.
 * Saleem Bhatti, Sep 2018.
 */
"use strict";

function valueToString(v) { // Not exhaustively tested: only for demo!
  if (v === null) { return "(null)"; } // null is not a type

  let s = "?";

  switch (typeof v) {

    case "number":
    case "boolean":
    case "symbol":
    s = v.toString();
    break;

    case "string":
    s = "\"" + v + "\"";
    break;

    case "function":
    s = "(function)";
    break;

    case "undefined":
    v = "(undefined)";
    break;

    case "object":
    s = objectDump(v);
    break;

    default: // should not get here!
    s = "?";
    break;
  }

  return (s);
}

function objectDump(o) {
  let s = "{";
  for (let p in o) {
    if (s != "{") { s = s + ", "; }
    let v = valueToString(o[p]);
    s = s + p + " : " + v;
  }
  s = s + "}";
  return s;
}


let arthur = new Object();

arthur.car = "Big Yellow Tractor";
arthur.name = "Arthur Dent";
arthur.age = 42;
arthur.confused = true;
arthur.occupation = "Traveller";
console.log("start ->\n" + objectDump(arthur) + "\n");

arthur.problems = "Lifestyle";
console.log("add 'problems' ->\n" + objectDump(arthur) + "\n");

delete arthur.car;
console.log("delete 'car' ->\n" + objectDump(arthur) + "\n");

arthur["age"] = "What an age!";
console.log("change age ->\n" + objectDump(arthur) + "\n");

arthur.age = null;
console.log("age to null ->\n" + objectDump(arthur) + "\n");

let hhgttg = new Object();
hhgttg.name = "Hitch Hiker's Guide to the Galaxy";
hhgttg.type = "Electronic";
hhgttg.version = 1;
hhgttg.description = "Don't Panic!";

arthur.book = hhgttg;

arthur.dump = function () { return objectDump(this); };
console.log("dump! ->\n" + arthur.dump());
