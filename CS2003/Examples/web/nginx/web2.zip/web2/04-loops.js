/*
 * Some examples of loops.
 * continue and break work as you might expect.
 * Saleem Bhatti, Sep 2018.
 */
"use strict";

let i1 = 42; // integer -- actually, floating point number
let i2 = 3;

let s1 = "forty_two"; // string
let s2 = "three";

let f1 = 42.424242; /* 64-bit floating point */
let f2 = 3.3333;

let array_1 = [42, 3, 42.424242, 3.3333];
let array_2 = [i1, i2, f1, f2];
let array_3 = [s1, 42, s2, 3];
let array_4a = {s1 : i1, s2 : i2, "42?" : f1, "3?" : f2}; // JSON object
let array_4b = {[s1] : i1, [s2] : i2, "42?" : f1, "3?" : f2}; // JSON object

let object_1 = [1, 2, 3];
object_1.s = "blob";

let i;

console.log("\narray_1");
for (i = 0; i < 4; ++i) {
  console.log(array_1[i]);
}

console.log("\narray_2");
i = 0;
while (i < 4) {
  console.log(array_2[i]);
  ++i;
}

console.log("\narray_3");
i = 0;
do {
  console.log(array_3[i]);
  ++i;
} while (i < 4);

console.log("\narray_4a - for-in");
for(let i in array_4a) {
  console.log(i + " : " + array_4a[i]);
}

console.log("\narray_4b - for-in");
for(let i in array_4b) {
  console.log(i + " : " + array_4b[i]);
}

console.log("\nobject_1 - for-in");
for(let i in object_1) {
  console.log(i);
}

console.log("\nobject_1 - for-of");
for(let i of object_1) {
  console.log(i);
}
